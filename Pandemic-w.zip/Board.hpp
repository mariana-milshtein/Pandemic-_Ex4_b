#pragma once
#include <iostream>
#include "CityInfo.hpp"

namespace pandemic {
	
}

class Board {
public:
	Board();
	~Board();
	
	void init();
	int& operator[](City);
	friend std::ostream& operator<<(std::ostream&, const Board&);

	bool is_clean();
	void remove_cures();
	void remove_stations();

	bool canReach(City, City);
	bool hasResearchStation(City);
	void build(City);
	bool has_cure(Color);
	void cure_city(City, int);
	void takeCard(City);
	Color getCityColor(City);
	void dropCard(City);
	void discover_cure(Color);

private:
	CityInfo** cities;
	bool* hasCure;
	const static int numberOfdisease = 4;
	const static int numberOfCities = 48;
};