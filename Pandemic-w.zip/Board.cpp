#include "Board.hpp"
#include <fstream>
#include <sstream>
#include <string>

Board::Board() {
	cities = new CityInfo*[Board::numberOfCities];
	hasCure = new bool[Board::numberOfdisease];
	init();
}

Board::~Board() {
	for (int i = 0; i < Board::numberOfCities; i++){
		delete cities[i];
	}
	delete cities;
	delete hasCure;
}

void Board::init() {
	std::ifstream citiesFile("cities.txt");
	std::string line;
	while (std::getline(citiesFile, line)) {
		std::istringstream iss(line);
		std::string cur_city, cur_color, next;
		iss >> cur_city;
		iss >> cur_color;
		City city = convert(cur_city);
		Color c = convert_c(cur_color);
		cities[city] = new CityInfo(city, c, cur_color);
		while (iss >> next) {
			cities[city]->nextDrive.push_back(convert(next));
		}
	}
	citiesFile.close();

	for (int i = 0; i < Board::numberOfdisease; i++) {
		hasCure[i] = false;
	}
}

int& Board::operator[](City city) {
	return cities[city]->disease_level;
}

std::ostream& operator<<(std::ostream& os, const Board& b) {
	for (int i = 0; i < Board::numberOfCities; i++) {
		os << "city: " << names[b.cities[i]->name] << " , color: " << colors[b.cities[i]->color] << " , disease_level: " << b.cities[i]->disease_level;
		if (b.cities[i]->researchStation) os << " , Has research station" << '\n';
		else os << '\n';
	}
	os << '\n';
	for (int i = 0; i < Board::numberOfdisease; i++) {
		if (b.hasCure[i]) os << colors[i] << " has a cure" << '\n';
		else os << colors[i] << " has no cure yet" << '\n';
	}
	return os;
}

bool Board::is_clean() {
	for (int i = 0; i < Board::numberOfCities; i++) {
		if (cities[i]->disease_level > 0) return false;
	}
	return true;
}

void Board::remove_cures() {
	for (int i = 0; i < Board::numberOfdisease; i++) {
		hasCure[i] = false;
	}
}

void Board::remove_stations() {
	for (int i = 0; i < Board::numberOfCities; i++) {
		cities[i]->researchStation = false;
	}
}

bool Board::canReach(City src, City dest) {
	std::vector<City> next = cities[src]->nextDrive;
	for (int i = 0; i < next.size(); i++) {
		if (next[i] == dest) return true;
	}
	return false;
}

bool Board::hasResearchStation(City city) {
	return cities[city]->researchStation;
}

void Board::build(City city) {
	cities[city]->researchStation = true;
}

bool Board::has_cure(Color color) {
	return hasCure[color];
}

void Board::cure_city(City city, int i) {
	if (i == 0) cities[city]->disease_level = 0;
	else if (cities[city]->disease_level == 0) throw std::exception("The city is already clean!");
	else if (hasCure[getCityColor(city)]) cities[city]->disease_level = 0;
	else cities[city]->disease_level--;
}

void Board::takeCard(City city) {
	cities[city]->available_card = false;
}

void Board::dropCard(City city) {
	cities[city]->available_card = true;
}

Color Board::getCityColor(City city) {
	return cities[city]->color;
}

void Board::discover_cure(Color disease) {
	hasCure[disease] = true;
}