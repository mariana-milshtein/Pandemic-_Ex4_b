#include "Researcher.hpp"

Researcher::Researcher(Board& board, City start_place) : Player(board, start_place) {
	pRole = "Researcher";
}

Researcher::~Researcher() {}

Player& Researcher::discover_cure(Color disease) {
	if (!board.has_cure(disease)) {
		if (hasNcards(disease, 5)) {
			dropNcards(disease, 5);
			board.discover_cure(disease);
		}
		else throw std::exception("Player dont have enought cards!");
	}
	return *this;
}