#pragma once
#include "Player.hpp"

class Scientist : public Player {
public:
	Scientist(Board&, City, int);
	~Scientist();

	Player& discover_cure(Color);

private:
	int n;
};