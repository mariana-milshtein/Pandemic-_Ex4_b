#include "FieldDoctor.hpp"

FieldDoctor::FieldDoctor(Board& board, City start_place) : Player(board, start_place) {
	pRole = "FieldDoctor";
}

FieldDoctor::~FieldDoctor() {}

Player& FieldDoctor::treat(City city) {
	if (city != place && !board.canReach(place,city)) throw std::exception("The city in not the player's range!");
	board.cure_city(city, 1);
	return *this;
}