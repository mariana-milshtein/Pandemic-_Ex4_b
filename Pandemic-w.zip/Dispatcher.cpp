#include "Dispatcher.hpp"

Dispatcher::Dispatcher(Board& board, City start_place) : Player(board, start_place) {
	pRole = "Dispatcher";
}

Dispatcher::~Dispatcher() {}

Player& Dispatcher::fly_direct(City dest) {
	if(board.hasResearchStation(place)) place = dest;
	else if (hasCard(dest)) {
		place = dest;
		dropCard(dest);
	}
	else throw std::exception("This player has not the card for dest city!");
	return *this;
}