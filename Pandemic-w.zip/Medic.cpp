#include "Medic.hpp"

Medic::Medic(Board& board, City start_place) : Player(board, start_place) {
	pRole = "Medic";
}

Medic::~Medic() {}

Player& Medic::drive(City dest) {
	if (board.canReach(place, dest)) {
		place = dest;
		if (board.has_cure(board.getCityColor(place))) board.cure_city(place, 0);
	}
	else throw std::exception("cannot reach this city from player's place!");
	return *this;
}

Player& Medic::fly_direct(City dest) {
	if (hasCard(dest)) {
		place = dest;
		if (board.has_cure(board.getCityColor(place))) board.cure_city(place, 0);
		dropCard(dest);
	}
	else throw std::exception("This player has not the card for dest city!");
	return *this;
}
Player& Medic::fly_charter(City dest) {
	if (hasCard(place)) {
		place = dest;
		if (board.has_cure(board.getCityColor(place))) board.cure_city(place, 0);
		dropCard(place);
	}
	else throw std::exception("This player has not the card for src city!");
	return *this;
}
Player& Medic::fly_shuttle(City dest) {
	if (board.hasResearchStation(place)) {
		place = dest;
		if(board.has_cure(board.getCityColor(place))) board.cure_city(place, 0);
	}
	else throw std::exception("This player has not the card for src city!");
	return *this;
}

Player& Medic::treat(City city) {
	if (city != place) throw std::exception("The city is not the player's place!");
	board.cure_city(place, 0);
	return *this;
}
