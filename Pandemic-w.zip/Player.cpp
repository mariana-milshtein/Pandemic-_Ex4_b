#include "Player.hpp"

Player::Player(Board& board, City start_place) : board(board) , place(start_place) {}

Player::~Player() {}

Player& Player::drive(City dest) {
	if (board.canReach(place, dest)) place = dest;
	else throw  std::exception("cannot reach this city from player's place!");
	return *this;
}

Player& Player::fly_direct(City dest) {
	if (hasCard(dest)) {
		place = dest;
		dropCard(dest);
	}
	else throw std::exception("This player has not the card for dest city!");
	return *this;
}
Player& Player::fly_charter(City dest) {
	if (hasCard(place)) {
		place = dest;
		dropCard(place);
	}
	else throw std::exception("This player has not the card for src city!");
	return *this;
}
Player& Player::fly_shuttle(City dest) {
	if (board.hasResearchStation(place) && board.hasResearchStation(dest)) place = dest;
	else throw std::exception("This player has not the card for src city!");
	return *this;
}
Player& Player::build() {
	if (!board.hasResearchStation(place)) {
		if (hasCard(place)) {
			dropCard(place);
			board.build(place);
		}
		else throw std::exception("This player has not the card for src city!");
	}
	return *this;
}
Player& Player::discover_cure(Color disease) {
	if (! board.has_cure(disease)) {
		if (board.hasResearchStation(place) && hasNcards(disease, 5)) {
			dropNcards(disease, 5);
			board.discover_cure(disease);
		}
		else if (board.hasResearchStation(place)) throw std::exception("Player dont have enought cards!");
		else throw std::exception("This city does not have research station for that!");
	}
	return *this;
}
Player& Player::treat(City city) {
	if (city != place) throw std::exception("The city in not the player's place!");
	board.cure_city(place,1);
	return *this;
}
Player& Player::take_card(City city) {
	if (std::find(cards.begin(), cards.end(), city) == cards.end()) {
		cards.push_back(city);
		board.takeCard(city);
	}
	return *this;
}

Player& Player::remove_cards() {
	for (int i = 0; i < cards.size(); i++){
		dropCard(cards[i]);
	}
	cards.clear();
	return *this;
}

bool Player::hasCard(City city) {
	for (int i = 0; i < cards.size(); i++) {
		if (cards[i] == city) return true;
	}
	return false;
}

bool Player::hasNcards(Color disease, int n) {
	int count = 0;
	for (int i = 0; i < cards.size(); i++) {
		if (board.getCityColor(cards[i]) == disease) {
			count++;
			if (count == n) return true;
		}
	}
	return false;
}

void Player::dropCard(City city) {
	for (int i = 0; i < cards.size(); i++) {
		if (cards[i] == city) {
			cards.erase(cards.begin() + i);
			board.dropCard(city);
		}
	}
}

void Player::dropNcards(Color disease, int n) {
	int count = 0;
	while (count < n) {
	for (int i = 0; i < cards.size(); i++) {
		if (board.getCityColor(cards[i]) == disease) {
			board.dropCard(cards[i]);
			cards.erase(cards.begin() + i);
			count++;
			break;
		}
	}
	}
}

std::string Player::role() {
	return pRole;
}
