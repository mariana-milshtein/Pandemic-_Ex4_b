#pragma once

#include <string>
#include "Color.hpp"

enum City {
	Algiers,
	Atlanta,
	Baghdad,
	Bangkok,
	Beijing,
	Bogota,
	BuenosAires,
	Cairo,
	Chennai,
	Chicago,
	Delhi,
	Essen,
	HoChiMinhCity,
	HongKong,
	Istanbul,
	Jakarta,
	Johannesburg,
	Karachi,
	Khartoum,
	Kinshasa,
	Kolkata,
	Lagos,
	Lima,
	London,
	LosAngeles,
	Madrid,
	Manila,
	MexicoCity,
	Miami,
	Milan,
	Montreal,
	Moscow,
	Mumbai,
	NewYork,
	Osaka,
	Paris,
	Riyadh,
	SanFrancisco,
	Santiago,
	SaoPaulo,
	Seoul,
	Shanghai,
	StPetersburg,
	Sydney,
	Taipei,
	Tehran,
	Tokyo,
	Washington
};

static std::string names[48] = {
	"Algiers",
	"Atlanta",
	"Baghdad",
	"Bangkok",
	"Beijing",
	"Bogota",
	"BuenosAires",
	"Cairo",
	"Chennai",
	"Chicago",
	"Delhi",
	"Essen",
	"HoChiMinhCity",
	"HongKong",
	"Istanbul",
	"Jakarta",
	"Johannesburg",
	"Karachi",
	"Khartoum",
	"Kinshasa",
	"Kolkata",
	"Lagos",
	"Lima",
	"London",
	"LosAngeles",
	"Madrid",
	"Manila",
	"MexicoCity",
	"Miami",
	"Milan",
	"Montreal",
	"Moscow",
	"Mumbai",
	"NewYork",
	"Osaka",
	"Paris",
	"Riyadh",
	"SanFrancisco",
	"Santiago",
	"SaoPaulo",
	"Seoul",
	"Shanghai",
	"StPetersburg",
	"Sydney",
	"Taipei",
	"Tehran",
	"Tokyo",
	"Washington"
};

static City convert(const std::string name) {
	if (name == "Algiers") return City::Algiers;
	if (name == "Atlanta") return City::Atlanta;
	if (name == "Baghdad") return City::Baghdad;
	if (name == "Bangkok") return City::Bangkok;
	if (name == "Beijing") return City::Beijing;
	if (name == "Bogota") return City::Bogota;
	if (name == "BuenosAires") return City::BuenosAires;
	if (name == "Cairo") return City::Cairo;
	if (name == "Chennai") return City::Chennai;
	if (name == "Chicago") return City::Chicago;
	if (name == "Delhi") return City::Delhi;
	if (name == "Essen") return City::Essen;
	if (name == "HoChiMinhCity") return City::HoChiMinhCity;
	if (name == "HongKong") return City::HongKong;
	if (name == "Istanbul") return City::Istanbul;
	if (name == "Jakarta") return City::Jakarta;
	if (name == "Johannesburg") return City::Johannesburg;
	if (name == "Karachi") return City::Karachi;
	if (name == "Khartoum") return City::Khartoum;
	if (name == "Kinshasa") return City::Kinshasa;
	if (name == "Kolkata") return City::Kolkata;
	if (name == "Lagos") return City::Lagos;
	if (name == "Lima") return City::Lima;
	if (name == "London") return City::London;
	if (name == "LosAngeles") return City::LosAngeles;
	if (name == "Madrid") return City::Madrid;
	if (name == "Manila") return City::Manila;
	if (name == "MexicoCity") return City::MexicoCity;
	if (name == "Miami") return City::Miami;
	if (name == "Milan") return City::Milan;
	if (name == "Montreal") return City::Montreal;
	if (name == "Moscow") return City::Moscow;
	if (name == "Mumbai") return City::Mumbai;
	if (name == "NewYork") return City::NewYork;
	if (name == "Osaka") return City::Osaka;
	if (name == "Paris") return City::Paris;
	if (name == "Riyadh") return City::Riyadh;
	if (name == "SanFrancisco") return City::SanFrancisco;
	if (name == "Santiago") return City::Santiago;
	if (name == "SaoPaulo") return City::SaoPaulo;
	if (name == "Seoul") return City::Seoul;
	if (name == "Shanghai") return City::Shanghai;
	if (name == "StPetersburg") return City::StPetersburg;
	if (name == "Sydney") return City::Sydney;
	if (name == "Taipei") return City::Taipei;
	if (name == "Tehran") return City::Tehran;
	if (name == "Tokyo") return City::Tokyo;
	if (name == "Washington") return City::Washington;
}
