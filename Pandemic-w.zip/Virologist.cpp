#include "Virologist.hpp"

Virologist::Virologist(Board& board, City start_place) : Player(board, start_place) {
	pRole = "Virologist";
}

Virologist::~Virologist() {}

Player& Virologist::treat(City city) {
	if (city != place) {
		if (hasCard(city)) {
			dropCard(city);
			board.cure_city(city, 1);
		}
		else throw std::exception("This player has not the card to treat given city!");
	}
	else board.cure_city(place, 1);
	return *this;
}