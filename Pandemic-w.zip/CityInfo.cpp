#include "CityInfo.hpp"

CityInfo::CityInfo(City name, Color color, std::string str_name) : name(name), color(color), str_name(str_name) {
	disease_level = 0;
	researchStation = false;
	available_card = true;
}

void CityInfo::addNextDrive(City city) {
	nextDrive.push_back(city);
}

CityInfo::~CityInfo() {}