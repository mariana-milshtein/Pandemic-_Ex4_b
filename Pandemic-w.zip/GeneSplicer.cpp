#include "GeneSplicer.hpp"

GeneSplicer::GeneSplicer(Board& board, City start_place) : Player(board, start_place) {
	pRole = "GeneSplicer";
}

GeneSplicer::~GeneSplicer() {}

Player& GeneSplicer::discover_cure(Color disease) {
	if (!board.has_cure(disease)) {
		if (board.hasResearchStation(place) && hasNcards()) {
			dropNcards();
			board.discover_cure(disease);
		}
		else if (board.hasResearchStation(place)) throw std::exception("Player dont have enought cards!");
		else throw std::exception("This city does not have research station for that!");
	}
	return *this;
}

bool GeneSplicer::hasNcards() {
	return cards.size() >= 5;
}

void GeneSplicer::dropNcards() {
	cards.erase(cards.begin(), cards.begin()+5);
}