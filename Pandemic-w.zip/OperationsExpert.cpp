#include "OperationsExpert.hpp"

OperationsExpert::OperationsExpert(Board& board, City start_place) : Player(board, start_place) {
	pRole = "OperationsExpert";
}

OperationsExpert::~OperationsExpert() {}

Player& OperationsExpert::build() {
	if (!board.hasResearchStation(place)) {
		board.build(place);
	}
	return *this;
}