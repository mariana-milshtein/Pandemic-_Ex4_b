#pragma once
#include <vector>
#include "City.hpp"
#include "Color.hpp"

class CityInfo {
public:
	CityInfo(City, Color,std::string);
	~CityInfo();

	void addNextDrive(City);

	City name;
	Color color;
	int disease_level;
	std::vector<City> nextDrive;
	bool researchStation;
	bool available_card;
	std::string str_name;
};
