#pragma once

enum Color {
	Blue, Yellow, Black, Red
};

static std::string colors[4]{
	"Blue",
	"Yellow",
	"Black",
	"Red"
};

static Color convert_c(const std::string name) {
	if (name == "Blue") return Color::Blue;
	if (name == "Red") return Color::Red;
	if (name == "Black") return Color::Black;
	if (name == "Yellow") return Color::Yellow;
}