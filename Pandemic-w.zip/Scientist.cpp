#include "Scientist.hpp"

Scientist::Scientist(Board& board, City start_place, int n) : Player(board, start_place), n(n) {
	pRole = "Scientist";
}

Scientist::~Scientist() {}

Player& Scientist::discover_cure(Color disease) {
	if (!board.has_cure(disease)) {
		if (board.hasResearchStation(place) && hasNcards(disease, n)) {
			dropNcards(disease, n);
			board.discover_cure(disease);
		}
		else if (board.hasResearchStation(place)) throw std::exception("Player dont have enought cards!");
		else throw std::exception("This city does not have research station for that!");
	}
	return *this;
}