#pragma once
#include "Player.hpp"

class GeneSplicer : public Player {
public:
	GeneSplicer(Board&, City);
	~GeneSplicer();

	Player& discover_cure(Color);

	bool hasNcards();
	void dropNcards();
};