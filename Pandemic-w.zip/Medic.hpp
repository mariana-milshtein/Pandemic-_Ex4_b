#pragma once
#include "Player.hpp"

class Medic : public Player {
public:
	Medic(Board&, City);
	~Medic();

	Player& drive(City);
	Player& fly_direct(City);
	Player& fly_charter(City);
	Player& fly_shuttle(City);
	Player& treat(City);
};