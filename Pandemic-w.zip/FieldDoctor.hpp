#pragma once
#include "Player.hpp"

class FieldDoctor : public Player {
public:
	FieldDoctor(Board&, City);
	~FieldDoctor();

	Player& treat(City);
};