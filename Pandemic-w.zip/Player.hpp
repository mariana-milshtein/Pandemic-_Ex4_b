#pragma once
#include "Board.hpp"
#include <string>
#include "City.hpp"

class Player {
public:
	Player(Board&, City);
	~Player();
	
	virtual Player& drive(City);
	virtual Player& fly_direct(City);
	virtual Player& fly_charter(City);
	virtual Player& fly_shuttle(City);
	virtual Player& build();
	virtual Player& discover_cure(Color);
	virtual Player& treat(City);
	Player& take_card(City);
	Player& remove_cards();

	std::string role();
	bool hasCard(City);
	bool hasNcards(Color, int);
	void dropCard(City);
	void dropNcards(Color, int);

	std::vector<City> cards;
protected:
	std::string pRole;
	Board& board;
	City place;

};